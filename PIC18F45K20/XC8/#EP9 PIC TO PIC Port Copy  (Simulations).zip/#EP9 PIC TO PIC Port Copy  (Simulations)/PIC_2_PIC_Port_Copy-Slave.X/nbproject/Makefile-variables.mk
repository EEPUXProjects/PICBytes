#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=PIC_2_PIC_Port_Copy-Slave.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/PIC_2_PIC_Port_Copy-Slave.X.production.hex
